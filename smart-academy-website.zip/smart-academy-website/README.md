# Smart Academy – Professional School Website

A modern, fully responsive website for **Smart Academy**.

## 📁 Folder Structure

```
smart-academy-website/
│
├── index.html                 ← Main homepage
│
├── css/
│   └── styles.css             ← All styling (colors, layout, responsive)
│
├── js/
│   └── script.js              ← Mobile menu, form handling, animations
│
├── assets/
│   ├── images/
│   │   ├── hero/              ← Hero/banner images
│   │   ├── gallery/           ← Campus & event photos
│   │   ├── team/              ← Teacher / staff photos
│   │   └── logo/              ← School logo files
│   ├── fonts/                 ← Custom fonts (optional)
│   └── videos/                ← Promo or campus videos
│
├── pages/                     ← Extra pages (about, admissions, etc.)
│
└── README.md                  ← This file
```

## Features

- Clean professional design (navy blue + gold)
- Fully responsive (mobile, tablet, desktop)
- Sticky navigation + mobile hamburger menu
- Smooth scrolling
- Contact form + newsletter form
- Scroll animations
- Ready for real images & multi-page expansion

## How to Use

1. Download and extract the folder
2. Open `index.html` in any browser
3. No server or installation needed

## Adding Real Photos

Put your images in the correct folders:

| Folder                    | Use for                  |
|---------------------------|--------------------------|
| `assets/images/hero/`     | Banner / homepage images |
| `assets/images/gallery/`  | Campus life photos       |
| `assets/images/team/`     | Teachers & staff         |
| `assets/images/logo/`     | School logo              |

Then update the HTML to use them, for example:

```html
<img src="assets/images/hero/campus.jpg" alt="Smart Academy Campus">
```

## Changing Colors

Open `css/styles.css` and edit the top variables:

```css
:root {
    --primary: #0a2540;   /* Dark navy */
    --accent:  #c9a227;   /* Gold */
}
```

## Deploy Online (Free)

- **Netlify** → drag & drop the folder
- **Vercel** → upload the project
- **GitHub Pages** → push to a repository

---

Made for **Smart Academy** © 2026
